# Terminal Snake
This is a simple snake game to play inside a shell, written in Python.
Simply run the `__init__.py` file inside the `terminal-snake` directory.
This project requires minimum Python 3.8. To create your own frontend you
can import the class `Game` from `game.py`.