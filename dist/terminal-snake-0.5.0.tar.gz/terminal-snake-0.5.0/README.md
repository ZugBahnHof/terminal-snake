# Terminal Snake
This is a simple snake game to play inside a shell, written in Python.
After installing (`pip install terminal_snake`) run the game with the command
`python -m terminal_snake`. To create your own frontend you can import the
class `Game` from this module. You can create different themes for this game
by creating a `Theme` object. 